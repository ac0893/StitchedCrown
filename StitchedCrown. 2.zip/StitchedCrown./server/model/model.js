const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    name : {
        type : String,
        required: true
    },
    email : {
        type: String,
        required: true,
        unique: true
    },
    texture: String,
    style : String,
    color: String, 
    status: String
})

const Orderdb = mongoose.model('orderdb', schema);

module.exports = Orderdb;