const express = require('express');
const route = express.Router();


const services = require('../services/render');
const controller = require('../controller/controller');


/**
 *  @description Root Route
 *  @method GET /
 */
route.get('/', services.homeRoutes);

/**
 *  @description add orders
 *  @method GET /add-order
 */
route.get('/add-order', services.add_order)

/**
 *  @description for update order
 *  @method GET /update-order
 */
route.get('/update-order', services.update_order)

//API
route.post('/api/orders',controller.create);
route.get('/api/orders',controller.find);
route.put('/api/orders/:id',controller.update);
route.delete('/api/orders/:id',controller.delete);



module.exports = route




